from flask import Flask, request, jsonify, abort, send_from_directory
from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes
from base64 import b64encode, b64decode
import time
import random

app = Flask(__name__)

note_db = {}

def encrypt_note(note_text):
    key = get_random_bytes(32)
    cipher = AES.new(key, AES.MODE_GCM)
    ciphertext, tag = cipher.encrypt_and_digest(note_text.encode())
    return {
        "ciphertext": b64encode(ciphertext).decode(),
        "nonce": b64encode(cipher.nonce).decode(),
        "tag": b64encode(tag).decode(),
        "key": b64encode(key).decode()
    }

def store_note(note_text, expiry_seconds=300, max_views=3):
    encrypted = encrypt_note(note_text)
    note_id = f"note{random.randint(1000,9999)}"
    expiry = time.time() + expiry_seconds
    note_db[note_id] = {
        "data": {
            "ciphertext": encrypted["ciphertext"],
            "nonce": encrypted["nonce"],
            "tag": encrypted["tag"]
        },
        "views_left": max_views,
        "expiry": expiry
    }
    return note_id, encrypted["key"]

@app.route('/')
def index():
    return send_from_directory('static', 'index.html')

@app.route('/create_note', methods=['POST'])
def create_note():
    data = request.json
    if not data or 'note' not in data:
        return jsonify({"error": "Missing note"}), 400

    note_text = data['note']
    expiry_seconds = int(data.get('expiry_seconds', 300))
    max_views = int(data.get('max_views', 3))

    note_id, key = store_note(note_text, expiry_seconds, max_views)
    return jsonify({"note_id": note_id, "key": key})

@app.route('/api/note/<note_id>')
def get_note(note_id):
    note = note_db.get(note_id)
    if not note:
        abort(404)
    if time.time() > note['expiry']:
        del note_db[note_id]
        abort(404)
    if note['views_left'] <= 0:
        del note_db[note_id]
        abort(404)

    note['views_left'] -= 1

    return jsonify(note['data'])

if __name__ == '__main__':
    app.run(debug=True)
